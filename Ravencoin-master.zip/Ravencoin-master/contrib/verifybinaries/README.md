### Verify Binaries

Verify the hash of the downloaded binaries against the published hash.
