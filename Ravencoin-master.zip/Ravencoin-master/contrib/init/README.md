Sample configuration files for:
```
SystemD: ravend.service
Upstart: ravend.conf
OpenRC:  ravend.openrc
         ravend.openrcconf
CentOS:  ravend.init
OS X:    org.raven.ravend.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
