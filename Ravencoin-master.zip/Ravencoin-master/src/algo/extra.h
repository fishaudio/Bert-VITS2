uint32_t be32dec(uint32_t *pp);
void be32enc(uint32_t *pp, uint32_t x);
uint32_t le32dec(uint32_t *pp);
void le32enc(uint32_t *pp, uint32_t x);
